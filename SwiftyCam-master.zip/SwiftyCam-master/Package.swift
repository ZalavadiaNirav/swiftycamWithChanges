import PackageDescription

let package = Package(
    name: "SwiftyCam"
)
